<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\Pembayaran;
use App\Models\Karyawan;
use App\Models\Mode;
use App\Models\RfidTemp;
use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function dashboard() {
        date_default_timezone_set('Asia/Jakarta');
        $karyawan = Karyawan::count();
        $curdate = date('Y-m-d');
        
        // Menghitung jumlah pegawai unik yang melakukan transaksi pada hari ini
        $uniqueKaryawanTransaksi = Pembayaran::whereDate('transaction_start', $curdate)
                                              ->distinct('uid')
                                              ->count('uid');
        
        return view('Dashboard.index', compact('karyawan', 'uniqueKaryawanTransaksi'));
    }       

    public function pembayaran() {
        $pembayaran = Pembayaran::all();
        return view('rekap.index', compact('pembayaran'));
    }

    public function scan() {
        return view('scan.index');
    }

    // realtime
    public function nokartu() {
        $data = RfidTemp::all();
        $cek = RfidTemp::all()->toArray();
        return view('Karyawan.nokartu', compact('data', 'cek'));
    }

    public function scan_payment() {
        RfidTemp::truncate();
        return view('scan.index');
    }

    public function scan_admin() {
        RfidTemp::truncate();
        return view('Top-Up.index');
    }
    
    public function reader() {
        $nama = "";
        $text_mode = "";
        $hasil = null;
        $saldo_awal = 0;
        $saldo_akhir = 0;
        $jumlah_pembayaran = 5000.00; // Jumlah pembayaran yang harus dibayar, misalnya 5000
        
        $data = RfidTemp::find(1);
        \Log::info('RFID Temp Data: ' . json_encode($data));
        $cek = RfidTemp::all()->toArray();
        $mode = Mode::first();
        $mode_pembayaran = $mode->mode;
        
        // Inisialisasi $transaction_count
        $transaction_count = 0;
        
        if ($mode_pembayaran == 1) {
            $text_mode = "Pembayaran Makanan";
        } elseif ($mode_pembayaran == 2) {
            // Jika ada mode lain, bisa ditambahkan di sini
        }
        
        if (empty($cek)) {
            $hasil = 1;
        } else {
            $rfid_masuk = $data->uid;
            \Log::info('RFID Masuk: ' . $rfid_masuk);
            $karyawan = Karyawan::where('uid', $rfid_masuk)->first();
            \Log::info('Karyawan Data: ' . json_encode($karyawan));
            if ($karyawan) {
                $nama = $karyawan->nama;
                $saldo_awal = $karyawan->saldo;
                \Log::info('Saldo Awal: ' . $saldo_awal);
                
                // Dapatkan tanggal dan waktu saat ini
                $tanggal_waktu_sekarang = now();
                $tanggal = $tanggal_waktu_sekarang->toDateString();
                $jam = $tanggal_waktu_sekarang->toTimeString();
        
                // Check for daily transaction limit
                $transaction_count = Pembayaran::where('uid', $rfid_masuk)->whereDate('transaction_date', $tanggal)->count();
                \Log::info('Jumlah Transaksi Hari Ini: ' . $transaction_count);
                if ($transaction_count >= 3) {
                    \Log::info('Batas transaksi harian tercapai.');
                    $hasil = 4; // Transaction limit reached
                } else {
                    if ($saldo_awal >= $jumlah_pembayaran) {
                        \Log::info('Saldo cukup untuk pembayaran');
                        $saldo_akhir = $saldo_awal - $jumlah_pembayaran;
                        \Log::info('Mengurangi saldo dari ' . $saldo_awal . ' menjadi ' . $saldo_akhir);
                        $karyawan->saldo = $saldo_akhir;
                        $karyawan->save();
        
                        // Tambahkan entri pembayaran
                        $insert_pembayaran = Pembayaran::create([
                            'uid' => $rfid_masuk,
                            'amount' => $jumlah_pembayaran,
                            'transaction_start' => $tanggal_waktu_sekarang, // Gunakan tanggal dan waktu sekarang
                            'transaction_date' => $tanggal,
                            'transaction_end' => $tanggal_waktu_sekarang, // Gunakan tanggal dan waktu sekarang
                            'saldo_awal' => $saldo_awal,
                            'saldo_akhir' => $saldo_akhir,
                        ]);
                        \Log::info('Transaksi Pembayaran Dicatat: ' . json_encode($insert_pembayaran));
        
                        $hasil = 0; // Berhasil melakukan pembayaran
                    } else {
                        \Log::info('Saldo tidak mencukupi untuk pembayaran');
                        $hasil = 3; // Saldo tidak mencukupi
                    }
                }
            } else {
                \Log::info('Karyawan tidak ditemukan');
                $hasil = 2; // Karyawan tidak ditemukan
            }
        }
    
        \Log::info('Hasil: ' . $hasil); // Add this line to log the result
        
        // Hapus data temporary RFID
        RfidTemp::truncate();
        return view('scan.reader', compact('hasil', 'text_mode', 'nama', 'saldo_awal', 'saldo_akhir', 'transaction_count'));
    
    }    
    
    // method dari arduino
    public function temp($id) {
        RfidTemp::truncate();
        RfidTemp::create(['uid' => $id]);
        return 'Kartu Masuk';
    }

    public function mode() {
        $data = Mode::first();
        $mode = $data->mode + 1;
        if ($mode > 2) {
            $mode = 1;
        }
        Mode::where('id', 1)->update(['mode' => $mode]);
        return "Mode Berhasil Diubah";
    }
}
