@extends('layout.main')
@section('title', 'Data Pembayaran')
@section('judul_halaman', 'History Pembayaran')

@section('isi')
<div class="card">
	<div class="table-responsive">
		<table id="example1" class="table table-striped table-md">
			<thead>
				<tr>
					<th>No</th>
					<th>Kode Rfid</th>
					<th>Nama Pegawai</th>
					<th>Waktu Transaksi</th>
					<th>Saldo Awal</th>
					<th>Saldo Akhir</th>
				</tr>
			</thead>
			<tbody>
			@foreach($pembayaran as $item)
			<tr>
			<td>{{$loop->iteration}}</td>
			<td>{{$item->uid}}</td>
			<td>
				@if ($item->karyawan)
					{{$item->karyawan->nama}}
				@else
					<!-- Tampilkan pesan atau nilai default jika $item->karyawan null -->
					(Karyawan Tidak Ditemukan)
				@endif
			</td>
			<td>{{$item->transaction_start}}</td>
			<td>{{$item->saldo_awal}}</td>
			<td>{{$item->saldo_akhir}}</td>
			</tr>
			@endforeach
			</tbody>
		</table>
	</div>
</div>
@endsection