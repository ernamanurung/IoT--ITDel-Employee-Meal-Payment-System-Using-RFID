@if($hasil == 1)
<center>
    <h3>Silahkan Tempelkan Kartu Anda Pada RFID Reader</h3>
    <h4>Mode Pembayaran: <span style="font-weight: bold;">{{$text_mode}}</span></h4>
    <img src="{{url('/assets_admin/img/scan/rfid.gif')}}" width="400" class="d-block">
    <img src="{{url('/assets_admin/img/scan/loading.gif')}}" width="500" style="margin-top: -93px;">
</center>
@elseif($hasil == 0)
<center>
    <h3>Anda Berhasil Melakukan Pembayaran</h3>
    <h3>Terima Kasih {{$nama}}</h3>
    <h4>Semoga Harimu Menyenangkan</h4>
    <h4>Saldo Awal: {{$saldo_awal}}</h4>
    <h4>Saldo Akhir: {{$saldo_akhir}}</h4>
    <h4>Transaksi Hari Ini: {{$transaction_count}}</h4>
</center>
@elseif($hasil == 2)
<center>
    <h3 style="color: red;">MAAF KARTU TIDAK DIKENALI !!!!!</h3>
</center>
@elseif($hasil == 3)
<center>
    <h3 style="color: red;">SALDO TIDAK MENCUKUPI !!!!!</h3>
</center>
@elseif($hasil == 4)
<center>
    <h3 style="color: red;">BATAS TRANSAKSI HARIAN TERCAPAI !!!!!</h3>
    <h4>Anda hanya dapat melakukan 3 transaksi per hari.</h4>
</center>
@endif