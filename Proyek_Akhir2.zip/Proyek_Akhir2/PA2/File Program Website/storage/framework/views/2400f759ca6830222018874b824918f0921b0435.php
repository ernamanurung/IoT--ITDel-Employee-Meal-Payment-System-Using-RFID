
<?php $__env->startSection('title', 'Tambah Data'); ?>
<?php $__env->startSection('judul_halaman', 'Tambah Data Karyawan'); ?>

<?php $__env->startSection('isi'); ?>
<script type="text/javascript">
  $(document).ready(function(){
      setInterval(function(){
        $("#nokartu").load('/nokartu')
      },0);
  });
</script>
		 <form action="<?php echo e(url('/postkaryawan')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                  
                    <div id="nokartu"></div>

                      <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Nama</label>
                      <div class="col-sm-12 col-md-7">
                        <input type="text" class="form-control"  name="nama" autocomplete="off" placeholder="Nama Pegawai">
                      </div>
                    </div>

                      <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Email</label>
                      <div class="col-sm-12 col-md-7">
                        <input type="text" class="form-control"  name="email" autocomplete="off" placeholder="example@gmail.com">
                      </div>
                    </div>

                      <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Jabatan</label>
                        <div class="col-sm-12 col-md-7">
                       <input type="text" class="form-control"  name="jabatan" autocomplete="off" placeholder="Jabatan">
                    </div>
                    </div>

                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Saldo</label>
                        <div class="col-sm-12 col-md-7">
                       <input type="text" class="form-control"  name="saldo" autocomplete="off" placeholder="Tambah Saldo">
                    </div>
                    </div>

                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                      <div class="col-sm-12 col-md-7">
                        <button class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(url('/karyawan')); ?>" class="btn btn-danger">Cancel</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyek_Akhir2\PA2\File Program Website\resources\views/karyawan/create.blade.php ENDPATH**/ ?>