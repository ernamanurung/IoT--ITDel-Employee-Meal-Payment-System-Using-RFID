
<?php $__env->startSection('title', 'Data Pembayaran'); ?>
<?php $__env->startSection('judul_halaman', 'History Pembayaran'); ?>

<?php $__env->startSection('isi'); ?>
<div class="card">
	<div class="table-responsive">
		<table id="example1" class="table table-striped table-md">
			<thead>
				<tr>
					<th>No</th>
					<th>Kode Rfid</th>
					<th>Nama Pegawai</th>
					<th>Waktu Transaksi</th>
					<th>Saldo Awal</th>
					<th>Saldo Akhir</th>
				</tr>
			</thead>
			<tbody>
			<?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
			<td><?php echo e($loop->iteration); ?></td>
			<td><?php echo e($item->uid); ?></td>
			<td>
				<?php if($item->karyawan): ?>
					<?php echo e($item->karyawan->nama); ?>

				<?php else: ?>
					<!-- Tampilkan pesan atau nilai default jika $item->karyawan null -->
					(Karyawan Tidak Ditemukan)
				<?php endif; ?>
			</td>
			<td><?php echo e($item->transaction_start); ?></td>
			<td><?php echo e($item->saldo_awal); ?></td>
			<td><?php echo e($item->saldo_akhir); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyek_Akhir2\PA2\File Program Website\resources\views/rekap/index.blade.php ENDPATH**/ ?>