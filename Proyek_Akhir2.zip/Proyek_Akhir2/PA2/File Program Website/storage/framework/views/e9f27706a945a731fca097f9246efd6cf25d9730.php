
<?php $__env->startSection('title', 'Payment'); ?>
<?php $__env->startSection('judul_halaman', 'Payment'); ?>
<?php $__env->startSection('isi'); ?>
<script type="text/javascript">
  $(document).ready(function(){
      setInterval(function(){
        $("#isi").load('/reader')
      },2000);
  });
</script>

<div class="card text-center">
	<div id="isi"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA2\File Program Website\resources\views/scan/index.blade.php ENDPATH**/ ?>