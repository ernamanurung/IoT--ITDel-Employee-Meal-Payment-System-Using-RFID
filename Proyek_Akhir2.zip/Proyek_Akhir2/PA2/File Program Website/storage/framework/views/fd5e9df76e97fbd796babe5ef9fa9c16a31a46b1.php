
<?php $__env->startSection('title', 'Data Pegawai'); ?>
<?php $__env->startSection('judul_halaman', 'Data Pegawai'); ?>

<?php $__env->startSection('isi'); ?>
<div class="row">
	<div class="col-md-9">
		<a href="<?php echo e(url('/tambah-karyawan')); ?>" class="btn btn-success adds ml-auto"><i class="fa fa-plus"></i> Tambah Data</a>
	</div>
	<div class="col-md-3">

	</div>
</div>
<div class="card">
	<div class="table-responsive">
		<table id="example1" class="table table-striped table-md">
			<thead>
				<tr>
					<th>No</th>
					<th>Kode Rfid</th>
					<th>Nama Pegawai</th>
					<th>Email</th>
					<th>Jabatan</th>
					<th>Saldo</th>
					<th class="text-center">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($item->uid); ?></td>
					<td><?php echo e($item->nama); ?></td>
					<td><?php echo e($item->email); ?></td>
					<td><?php echo e($item->jabatan); ?></td>
					<td><?php echo e($item->saldo); ?></td>
					<td class="text-center"><a href="<?php echo e(url('/edit-karyawan/'.$item->id.'')); ?>" class="btn btn-warning">Edit</a> 
					<a href="<?php echo e(url('/hapus-karyawan/'.$item->id.'')); ?>" class="btn btn-danger confirm">Hapus</a>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>


		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyek_Akhir2\PA2\File Program Website\resources\views/karyawan/index.blade.php ENDPATH**/ ?>