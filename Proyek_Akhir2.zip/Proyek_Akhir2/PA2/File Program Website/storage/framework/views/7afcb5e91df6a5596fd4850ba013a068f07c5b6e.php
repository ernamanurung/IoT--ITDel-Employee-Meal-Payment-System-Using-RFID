<?php if($hasil == 1): ?>
<center>
    <h3>Silahkan Tempelkan Kartu Anda Pada RFID Reader</h3>
    <h4>Mode Pembayaran: <span style="font-weight: bold;"><?php echo e($text_mode); ?></span></h4>
    <img src="<?php echo e(url('/assets_admin/img/scan/rfid.gif')); ?>" width="400" class="d-block">
    <img src="<?php echo e(url('/assets_admin/img/scan/loading.gif')); ?>" width="500" style="margin-top: -93px;">
</center>
<?php elseif($hasil == 0): ?>
<center>
    <h3>Anda Berhasil Melakukan Pembayaran</h3>
    <h3>Terima Kasih <?php echo e($nama); ?></h3>
    <h4>Semoga Harimu Menyenangkan</h4>
    <h4>Saldo Awal: <?php echo e($saldo_awal); ?></h4>
    <h4>Saldo Akhir: <?php echo e($saldo_akhir); ?></h4>
    <h4>Transaksi Hari Ini: <?php echo e($transaction_count); ?></h4>
</center>
<?php elseif($hasil == 2): ?>
<center>
    <h3 style="color: red;">MAAF KARTU TIDAK DIKENALI !!!!!</h3>
</center>
<?php elseif($hasil == 3): ?>
<center>
    <h3 style="color: red;">SALDO TIDAK MENCUKUPI !!!!!</h3>
</center>
<?php elseif($hasil == 4): ?>
<center>
    <h3 style="color: red;">BATAS TRANSAKSI HARIAN TERCAPAI !!!!!</h3>
    <h4>Anda hanya dapat melakukan 3 transaksi per hari.</h4>
</center>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PA2\File Program Website\resources\views/scan/reader.blade.php ENDPATH**/ ?>