<?php if(!empty($cek)): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">No Kartu</label>
                      <div class="col-sm-12 col-md-7">
                        <input type="text" class="form-control" readonly  name="kartu" autocomplete="off" value="<?php echo e($item->uid); ?>">
                      </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
<?php else: ?>
	<div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">No Kartu</label>
                      <div class="col-sm-12 col-md-7">
                        <input type="text" class="form-control" readonly  name="kartu" autocomplete="off" placeholder="Tempelkan Kartu pada perangkat" value="">
                      </div>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PA2\File Program Website\resources\views/Karyawan/nokartu.blade.php ENDPATH**/ ?>