<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1><?php echo $__env->yieldContent('judul_halaman'); ?></h1>
          </div>
          	<?php echo $__env->yieldContent('isi'); ?>
          <div class="section-body">
          </div>
        </section>
      </div>
  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyek_Akhir2\PA2\File Program Website\resources\views/layout/main.blade.php ENDPATH**/ ?>