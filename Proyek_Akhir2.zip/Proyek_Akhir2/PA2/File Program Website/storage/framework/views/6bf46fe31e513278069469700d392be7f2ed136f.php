
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('judul_halaman', 'SELAMAT DATANG DI SISTEM PEMBAYARAN MAKAN PEGAWAI RFID'); ?>

<?php $__env->startSection('isi'); ?>
 <div class="row">
            <div class="col-md-6">
              <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                  <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Jumlah Pegawai</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($karyawan); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                  <i class="far fa-calendar"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Jumlah Pegawai yang makan hari ini</h4>
                  </div>
                  <div class="card-body">
                  <?php echo e($uniqueKaryawanTransaksi); ?>

                  </div>
                </div>
              </div>
            </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyek_Akhir2\PA2\File Program Website\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>